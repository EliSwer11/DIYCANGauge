var class_mega_c_a_n =
[
    [ "MegaCAN", "class_mega_c_a_n.html#a6b3d339d000dfc4b5a4f45778e296ce8", null ],
    [ "getBCastData", "class_mega_c_a_n.html#a93a0f4768ce256e4c90a3dfeb5873c34", null ],
    [ "processMSreq", "class_mega_c_a_n.html#a4143c5cce1ca2dceb452f45a94e3770e", null ],
    [ "setMSresp", "class_mega_c_a_n.html#a7eb033e98b17a142ab37467702d1f627", null ]
];