var annotated_dup =
[
    [ "MegaCAN", "class_mega_c_a_n.html", "class_mega_c_a_n" ],
    [ "MegaCAN_broadcast_message_t", "struct_mega_c_a_n__broadcast__message__t.html", "struct_mega_c_a_n__broadcast__message__t" ],
    [ "MegaCAN_message_t", "struct_mega_c_a_n__message__t.html", "struct_mega_c_a_n__message__t" ]
];