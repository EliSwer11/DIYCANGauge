var struct_mega_c_a_n__message__t =
[
    [ "core", "struct_mega_c_a_n__message__t.html#a0121d18f06d2f5c094c8eadc30a587fe", null ],
    [ "data", "struct_mega_c_a_n__message__t.html#a1aebb0f01a7fe986b2377e16fa7ed6e1", null ],
    [ "fromID", "struct_mega_c_a_n__message__t.html#ae9dfc8386d9253f1f7897113c58c0ade", null ],
    [ "msgType", "struct_mega_c_a_n__message__t.html#ad584892d95bd438bdc593156d2e472ba", null ],
    [ "request", "struct_mega_c_a_n__message__t.html#a12c1a43d18a2eb4ac14aef1af6c74ead", null ],
    [ "response", "struct_mega_c_a_n__message__t.html#a26c93d99625ae2cbc149c459c857cdd3", null ],
    [ "responseCore", "struct_mega_c_a_n__message__t.html#a8fdc65f41839c48df6deacc97b017318", null ],
    [ "toID", "struct_mega_c_a_n__message__t.html#a3364c87092972d2fe9b224b18b58f01d", null ],
    [ "toOffset", "struct_mega_c_a_n__message__t.html#a6ae95c116018c25960a3f0ba0828a2d3", null ],
    [ "toTable", "struct_mega_c_a_n__message__t.html#ab76f32db9e49b39ae5ed062720fd97bc", null ],
    [ "varBlk", "struct_mega_c_a_n__message__t.html#a3443a2c6dc5483f0000b60c4350901ae", null ],
    [ "varByt", "struct_mega_c_a_n__message__t.html#ac8efe9667147dd6f63c33443a983e040", null ],
    [ "varOffset", "struct_mega_c_a_n__message__t.html#ac05b7710daeee87dd2139fa0cc8c6f2b", null ]
];